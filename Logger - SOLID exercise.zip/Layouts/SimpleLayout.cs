﻿namespace Logger.Layouts
{
    using Contracts;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class SimpleLayout : ILayout
    {

        public string Format => "{0} - {1} - {2}";

    }
}
