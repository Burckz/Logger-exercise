﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.LogFIle_Contract
{
    public interface ILogFile
    {
        int Size();
    }
}
